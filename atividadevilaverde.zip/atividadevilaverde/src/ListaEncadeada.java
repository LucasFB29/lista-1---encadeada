import java.util.Scanner;

public class ListaEncadeada {
    private static class No {
        public String dado;
        public No proximo;

        public No(String dado) {
            this.dado = dado;
            this.proximo = null;
        }
    }

    private No primeiro;

    public ListaEncadeada() {
        this.primeiro = null;
    }

    public void inserir(String dado) {
        No novoNo = new No(dado);
        if (this.primeiro == null) {
            this.primeiro = novoNo;
        } else {
            No atual = this.primeiro;
            while (atual.proximo != null) {
                atual = atual.proximo;
            }
            atual.proximo = novoNo;
        }
    }

    public boolean excluir(String dado) {
        No atual = this.primeiro;
        No anterior = null;

        while (atual != null) {
            if (atual.dado.equals(dado)) {
                if (anterior != null) {
                    anterior.proximo = atual.proximo;
                } else {
                    this.primeiro = atual.proximo;
                }
                return true;
            }
            anterior = atual;
            atual = atual.proximo;
        }
        return false;
    }

    public void imprimir() {
        No atual = this.primeiro;
        while (atual != null) {
            System.out.println(atual.dado);
            atual = atual.proximo;
        }
    }

    public static void main(String[] args) {
        ListaEncadeada lista = new ListaEncadeada();

        // Inserindo três elementos na lista
        lista.inserir("elemento1");
        lista.inserir("elemento2");
        lista.inserir("elemento3");

        // Imprimindo os elementos
        System.out.println("Elementos da lista:");
        lista.imprimir();

        // Solicitando ao usuário para inserir um elemento
        Scanner scanner = new Scanner(System.in);
        System.out.println("\nDigite um elemento para inserir na lista:");
        String elementoInserir = scanner.nextLine();
        lista.inserir(elementoInserir);

        // Imprimindo os elementos atualizados
        System.out.println("\nElementos da lista após inserção:");
        lista.imprimir();

        // Solicitando ao usuário para excluir um elemento
        System.out.println("\nDigite um elemento para excluir da lista:");
        String elementoExcluir = scanner.nextLine();
        if (lista.excluir(elementoExcluir)) {
            System.out.println("Elemento " + elementoExcluir + " excluído com sucesso!");
        } else {
            System.out.println("Elemento " + elementoExcluir + " não encontrado na lista.");
        }

        // Imprimindo os elementos atualizados
        System.out.println("\nElementos da lista após exclusão:");
        lista.imprimir();

        scanner.close();
    }
}