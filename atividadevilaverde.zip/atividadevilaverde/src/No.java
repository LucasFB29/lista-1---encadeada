public class No {
    public String dado;
    public No proximo;

    public No(String dado) {
        this.dado = dado;
        this.proximo = null;
    }
}